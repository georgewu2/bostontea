//
//  Annotation.m
//  Where's My T?
//
//  Created by George Wu on 12/9/12.
//  Copyright (c) 2012 George Luke. All rights reserved.
//

#import "Annotation.h"

@implementation Annotation

@synthesize coordinate, title;

@end
