//
//  main.m
//  Where's My T?
//
//  Created by George Wu on 11/30/12.
//  Copyright (c) 2012 George Luke. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
